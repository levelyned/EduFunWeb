@extends('layouts.master')
@section('content')
    <div class="content-fluid p-5 d-flex flex-column align-items-center" style="background-color: #d1e5f4">
        <h3 class="">Our Writer</h3>
        @include('components.writerCard', ['authors'=>$authors])
    </div>
@endsection
