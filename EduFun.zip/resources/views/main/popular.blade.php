@extends('layouts.master')
@section('content')
    <div class="container-fluid p-5 d-flex flex-column align-items-center" style="background-color: #d1e5f4">
        <h3 class="">Popular</h3>
        @include('components.articleCard', ['articles'=>$article])
        <div class="d-flex justify-content-center pt-3">
            {{$article->links()}}
        </div>
    </div>

@endsection
