@extends('layouts.master')
@section('content')
    <div class="" style="background-image: url(/image/HeroSection.jpg); height: 600px; background-position: center -100px;"></div>
    <div class="container-fluid d-flex p-5 flex-column align-items-center" style="background-color: #d1e5f4">
        @include('components.articleCard', ['articles' => $article]);
    </div>
@endsection
