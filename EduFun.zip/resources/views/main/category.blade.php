@extends('layouts.master')
@section('content')
    <div class="container-fluid p-5 d-flex flex-column align-items-center" style="background-color: #d1e5f4">
       <h3 class="">{{$categories->name}}</h3>
    </div>
    @include('components.articlecard', ['articles'=>$categories->articles]);
@endsection
