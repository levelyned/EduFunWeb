@extends('layouts.master')
@section('content')
    <div class="d-flex flex-column container-fluid align-items-center px-5 py-3" style="background-color: #d1e5f4">
        <div class="d-flex flex-column align-items-start p-3 gap-3">
            <div class="d-flex flex-row justify-content-center px-3 gap-5">
                <img src={{ asset('image/' . $author->photo) }} alt="" class="card-img-center rounded-circle" alt="..." style="width:80px; height:80px; object-fit: cover;">
                <div class="d-flex flex-column align-items-center gap-3">
                    <h5 class="">{{$author->name}}</h5>
                    <p class="">{{$author->specialist}}</p>
                </div>
            </div>
            @include('components.articleCard', ['articles'=>$author->articles])
        </div>
    </div>
@endsection
