@extends('layouts.master')
@section('content')
    <div class="container-fluid d-flex flex-column align-items-center px-5 py-3" style="background-color: #d1e5f4">
        <img src="{{ asset('image/' . $article->photo) }}" alt="" class="" style="width:1000px; height:600px; border-radius:20px">
        <div class="d-flex flex-column align-items-start px-3">
            <p class="pt-2">{{$article->date}} | by : {{$article->author->name}}</p>
            <p class="pb-4">{{$article->desc}}</p>
        </div>
    </div>
@endsection
