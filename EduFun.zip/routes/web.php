<?php

use App\Http\Controllers\ArticlesController;
use App\Http\Controllers\AuthorsController;
use App\Http\Controllers\CategoriesController;
use Illuminate\Support\Facades\Route;

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('/', [ArticlesController::class, 'getAllArticles'])->name('homePage');
Route::get('/category/{id}', [CategoriesController::class, 'getCategoryById'])->name('categoryPage');
Route::get('/popular', [ArticlesController::class, 'getPopularArticles'])->name('popularPage');
Route::get('/aboutUs', function(){
    return view('main.aboutUs');
})->name('aboutUsPage');
Route::get('/writer', [AuthorsController::class, 'getAllAuthors'])->name('writerPage');
Route::get('/article/{id}', [ArticlesController::class, 'getArticleById'])->name('articleDetailPage');
Route::get('/write/{id}', [AuthorsController::class, 'getAuthorById'])->name('writerDetail');
