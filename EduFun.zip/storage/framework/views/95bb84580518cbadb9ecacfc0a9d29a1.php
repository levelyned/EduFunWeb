<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-5 d-flex flex-column align-items-center" style="background-color: #d1e5f4">
        <h3 class="">Popular</h3>
        <?php echo $__env->make('components.articleCard', ['articles'=>$article], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="d-flex justify-content-center pt-3">
            <?php echo e($article->links()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\epelo\EduFun\resources\views/main/popular.blade.php ENDPATH**/ ?>