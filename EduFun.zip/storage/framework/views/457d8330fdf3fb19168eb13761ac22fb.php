<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-5 d-flex flex-column align-items-center" style="background-color: #d1e5f4">
        <h2 class="px-5 pb-4 mx-5">About EduFun</h2>
        <div class="px-5 pb-4 mx-5">
            <p class="text-center fs-5 px-5 mx-5">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quisquam, quas neque recusandae omnis eum libero, aliquam est dignissimos beatae sit labore, ipsam veritatis ea voluptatem. Explicabo corporis libero eum dolore? Lorem ipsum dolor sit amet, consectetur adipisicing elit. Deserunt at iste in consectetur tempore molestiae quidem inventore, possimus sint alias numquam quo dolores qui. Ex eos natus architecto quam similique. Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex ea nesciunt excepturi aspernatur, esse sunt impedit voluptatem voluptates natus? Esse temporibus provident ea illum expedita modi voluptatum, deleniti officiis facilis.</p>
        </div>
        <div class="px-5 pb-3 mx-5">
            <p class="text-center fs-5 px-5 mx-5">Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium molestiae repudiandae laborum esse, fugiat modi inventore accusamus, corrupti qui sequi ratione recusandae sed magnam quaerat doloribus beatae odio, culpa ipsam. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolor assumenda vel tempore labore, inventore non laborum quasi maxime unde facilis corrupti, at temporibus, magnam eaque itaque atque impedit consectetur praesentium? Lorem ipsum dolor sit amet consectetur adipisicing elit. Unde iusto aperiam impedit molestiae dignissimos quidem numquam aliquid perferendis, minima, corporis modi cumque nesciunt beatae dolore ad. Temporibus voluptates quas omnis?</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\epelo\EduFun\resources\views/main/aboutUs.blade.php ENDPATH**/ ?>