<?php $__env->startSection('content'); ?>
    <div class="" style="background-image: url(/image/HeroSection.jpg); height: 600px; background-position: center -100px;"></div>
    <div class="container-fluid d-flex p-5 flex-column align-items-center" style="background-color: #d1e5f4">
        <?php echo $__env->make('components.articleCard', ['articles' => $article], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\epelo\EduFun\resources\views/main/home.blade.php ENDPATH**/ ?>