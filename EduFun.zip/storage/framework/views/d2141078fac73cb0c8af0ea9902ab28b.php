<div class="d-flex justify-content-center py-5" style="background-color: rgb(2, 2, 62)">
    <div class="text-white text-center">
        EduFun 2024 | Web Programming | Evelyn Angelica | 2602097492
    </div>
</div>
<?php /**PATH C:\Users\epelo\EduFun\resources\views/components/footer.blade.php ENDPATH**/ ?>