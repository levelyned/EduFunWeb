<?php $__env->startSection('content'); ?>
    <div class="content-fluid p-5 d-flex flex-column align-items-center" style="background-color: #d1e5f4">
        <h3 class="">Our Writer</h3>
        <?php echo $__env->make('components.writerCard', ['authors'=>$authors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\epelo\EduFun\resources\views/main/writer.blade.php ENDPATH**/ ?>