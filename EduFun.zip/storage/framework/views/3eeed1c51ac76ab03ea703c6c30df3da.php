<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-5 d-flex flex-column align-items-center" style="background-color: #d1e5f4">
       <h3 class=""><?php echo e($categories->name); ?></h3>
    </div>
    <?php echo $__env->make('components.articlecard', ['articles'=>$categories->articles], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\epelo\EduFun\resources\views/main/category.blade.php ENDPATH**/ ?>