<?php $__env->startSection('content'); ?>
    <div class="container-fluid d-flex flex-column align-items-center px-5 py-3" style="background-color: #d1e5f4">
        <img src="<?php echo e(asset('image/' . $article->photo)); ?>" alt="" class="" style="width:1000px; height:600px; border-radius:20px">
        <div class="d-flex flex-column align-items-start px-3">
            <p class="pt-2"><?php echo e($article->date); ?> | by : <?php echo e($article->author->name); ?></p>
            <p class="pb-4"><?php echo e($article->desc); ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\epelo\EduFun\resources\views/main/articleDetail.blade.php ENDPATH**/ ?>