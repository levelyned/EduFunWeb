<div class="container d-flex flex-column align-items-center gap-4">
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card d-flex flex-row" style="width: 65rem;">
        <img src="<?php echo e(asset('image/' . $item->photo)); ?>" class="card-img-top" alt="..." style="border-radius:20px; height:250px; width:600px">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($item->title); ?></h5>
            <div class="date">
                <?php echo e(date('Y m d', strtotime($item->date))); ?> | by : <?php echo e(strstr($item->Author->name, ' ', true)); ?>

            </div>
        <p class="card-text"><?php echo e(substr($item->desc, 0, 150)); ?>...</p>
        <a href=<?php echo e(route('articleDetailPage', $item->id)); ?> class="btn btn-primary d-flex float-end justify-content-center" style="background-color: rgb(2, 2, 62); border-radius:100px; width:150px;">Read More</a>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH C:\Users\epelo\EduFun\resources\views/components/articlecard.blade.php ENDPATH**/ ?>