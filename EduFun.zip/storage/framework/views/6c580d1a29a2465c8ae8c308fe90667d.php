<div class="container d-flex flex-row justify-content-center p-5 gap-4">
    <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card d-flex flex-column align-items-center" style="width: 18rem; border-color:transparent; background-color:transparent;">
        <a href=<?php echo e(route('writerDetail', $item->id)); ?> class="">
            <img src="<?php echo e(asset('image/' . $item->photo)); ?>" class="card-img-center rounded-circle" alt="..." style="width: 150px; height: 150px; object-fit: cover;">
        </a>
    <div class="card-body d-flex flex-column align-items-center">
        <a href=<?php echo e(route('writerDetail', $item->id)); ?> class="text-decoration-none text-dark">
            <h5 class="card-title"><?php echo e($item->name); ?></h5>
        </a>
    <p class="card-text"><?php echo e($item->specialist); ?></p>
      
    </div>
  </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH C:\Users\epelo\EduFun\resources\views/components/writerCard.blade.php ENDPATH**/ ?>